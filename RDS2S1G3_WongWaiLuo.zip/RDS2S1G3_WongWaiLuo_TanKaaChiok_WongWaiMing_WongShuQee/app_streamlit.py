import streamlit as st
import joblib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import kagglehub

# App title
st.title("Diamond Price Prediction (Random Forest Regressor)")

# Load the trained Random Forest model
@st.cache_resource
def load_model():
    try:
        model = joblib.load("C:\\Users\\wlwon\\OneDrive\\Documents\\OneDrive\\Desktop\\streamlit\\best_model.joblib")  # Random Forest only
        st.success("Random Forest Regressor model loaded successfully.")
        return model
    except Exception as e:
        st.error(f"Could not load model: {e}")
        return None

model = load_model()

# Load dataset only for plotting
@st.cache_data
def load_diamond_data():
    try:
        path = kagglehub.dataset_download("nancyalaswad90/diamonds-prices")
        diamond_df = pd.read_csv(f"{path}/Diamonds Prices2022.csv")
        diamond_df = diamond_df.drop(columns="Unnamed: 0", errors="ignore")
        diamond_df = diamond_df.drop_duplicates()
        diamond_df = diamond_df[(diamond_df["x"] > 0) & (diamond_df["y"] > 0) & (diamond_df["z"] > 0)]
        diamond_df["volume"] = diamond_df["x"] * diamond_df["y"] * diamond_df["z"]
        return diamond_df
    except Exception:
        return pd.DataFrame()

diamond_df = load_diamond_data()

# Sidebar input widgets
st.sidebar.header("Enter Diamond Features")

carat = st.sidebar.number_input("Carat", min_value=0.1, value=0.5, step=0.01)

cut_options = ["Fair", "Good", "Very Good", "Premium", "Ideal"]
cut = st.sidebar.selectbox("Cut", cut_options, index=4)

color_options = ["D", "E", "F", "G", "H", "I", "J"]
color = st.sidebar.selectbox("Color", color_options, index=1)

clarity_options = ["I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"]
clarity = st.sidebar.selectbox("Clarity", clarity_options, index=3)

depth = st.sidebar.number_input("Depth (%)", min_value=0.0, value=61.8, step=0.1)
table = st.sidebar.number_input("Table (%)", min_value=0.0, value=57.0, step=0.1)
x = st.sidebar.number_input("Length (mm)", min_value=0.0, value=5.1, step=0.01)
y = st.sidebar.number_input("Width (mm)", min_value=0.0, value=5.15, step=0.01)
z = st.sidebar.number_input("Depth (mm)", min_value=0.0, value=3.16, step=0.01)

# Prediction
if st.sidebar.button("Predict Price"):
    if model is not None:
        try:
            volume = x * y * z
            input_data = pd.DataFrame({
                "carat": [carat],
                "cut": [cut],
                "color": [color],
                "clarity": [clarity],
                "depth": [depth],
                "table": [table],
                "x": [x],
                "y": [y],
                "z": [z],
                "volume": [volume],
            })

            predicted_price = model.predict(input_data)[0]

            st.subheader("Predicted Diamond Price:")
            st.write(f"${predicted_price:,.2f}")

            st.subheader("Input Features Used:")
            st.write(input_data)

            # Plot dataset vs prediction
            if not diamond_df.empty:
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.scatterplot(data=diamond_df, x="carat", y="price", alpha=0.5, label="Dataset Diamonds", ax=ax)
                ax.scatter(carat, predicted_price, color="red", s=150, label="Predicted Diamond",
                           edgecolors="black", zorder=5)
                ax.set_title("Diamond Price vs. Carat")
                ax.set_xlabel("Carat")
                ax.set_ylabel("Price")
                ax.legend()
                ax.grid(True)
                st.pyplot(fig)
            else:
                st.warning("Could not load dataset for plotting.")

        except Exception as e:
            st.error(f"An error occurred during prediction: {e}")
    else:
        st.warning("Model not loaded, cannot make predictions.")

# Instructions
st.markdown("""
### How to run this Streamlit app:
1. Save this file as `app_streamlit.py`.
2. Make sure `best_model.joblib` (Random Forest model) is in the same folder.
3. Run:
   `!streamlit run app_streamlit.py & npx localtunnel --port 8501`
4. Open the public URL shown by localtunnel.
""")
